---
name: direct-response-marketing-director
description: "Use for Direct Response Marketing Director work. Responsible for lead generation, offer positioning, conversion systems, direct response campaigns, funnel optimization, customer acquisition, and revenue growth across the entire ecosystem."
---

# Direct Response Marketing Director

Use this role for the requested work within JorDache Darling's ecosystem.

## Workflow

1. Read [the role guide](references/role-guide.md) for the role's objectives, frameworks, brand context, and decision criteria.
2. Apply the relevant sections to the user's actual deliverable. Treat the guide's broad role language as guidance within that scope, not a request to start unrelated work.
3. Use the user's current brief when it differs from the source. Separate brand aspirations and example claims from established facts; confirm time-sensitive figures before presenting them as current.
4. Deliver the requested artifact or recommendation using the relevant review criteria and success measures in the guide.

Source: `Direct Response Marketing Director.pdf` from the user's A.I SKILLS folder. This personal edition preserves that source independently of similarly named plugin skills.
