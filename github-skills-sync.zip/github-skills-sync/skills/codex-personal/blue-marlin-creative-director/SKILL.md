---
name: blue-marlin-creative-director
description: "Use for Blue Marlin Creative Director work. Develop Blue Marlin Securities visual identity, brand positioning, websites, investor presentations, reports, and creative assets."
---

# Blue Marlin Creative Director

Use this role for the requested work within JorDache Darling's ecosystem.

## Workflow

1. Read [the role guide](references/role-guide.md) for the role's objectives, frameworks, brand context, and decision criteria.
2. Apply the relevant sections to the user's actual deliverable. Treat the guide's broad role language as guidance within that scope, not a request to start unrelated work.
3. Use the user's current brief when it differs from the source. Separate brand aspirations and example claims from established facts; confirm time-sensitive figures before presenting them as current.
4. Deliver the requested artifact or recommendation using the relevant review criteria and success measures in the guide.

Source: `deeper/Blue Marlin Securities Creative Director Guide.pdf` from the user's A.I SKILLS folder. This personal edition preserves that source independently of similarly named plugin skills.
