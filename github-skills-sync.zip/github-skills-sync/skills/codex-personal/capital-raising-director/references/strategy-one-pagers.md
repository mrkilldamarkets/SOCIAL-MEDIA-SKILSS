Blue Marlin Securities — Strategy Overview
Capital Allocation Platform
Blue Marlin Securities
Managed Capital · Verified Track Record · Institutional Process
Heist V7
● Live
Blue Marlin
● Live
Oracle
Pipeline
⬡ Export / Print
Algorithmic Strategy · Gold (XAUUSD)
Heist V7
A systematic, rules-based algorithmic strategy trading Gold exclusively. Designed for capital growth through disciplined execution across high-probability institutional order flow setups — without discretionary interference.
Live · Verified Track Record · Accepting Allocations
Performance Summary — Inception to June 2026
Total Gain
+58.98%
Since August 2025
Avg Monthly Return
4.95%
Over 9.5 months live
Account Size
$7.17M
Live verified balance
Net Profit Generated
$1.97M
Verified on Myfxbook
Max Drawdown
26.21%
Recovered — see note
Live Since
Aug '25
9+ months continuous
The 26.21% maximum drawdown occurred during an extreme volatility event in October 2025. The strategy recovered and went on to produce its strongest period of performance in the months following. Risk parameters have since been refined. Drawdown context and full trade history are available upon request.
⬡  Track record verified via Myfxbook · Real (USD) account · Tag Markets · MT5 · Manual/Algorithmic · 1:100 leverage
Strategy Profile
Trades Gold (XAUUSD) exclusively
Algorithmic execution — no emotional interference
Rules-based entries on institutional order flow
BOS/CHoCH, order block and FVG identification
Active risk management per trade and per session
Geopolitical risk filter integrated
Why Gold
Gold is one of the most institutionally traded markets globally. It provides deep liquidity, strong directional bias during macro events, and a clear relationship between price and order flow — creating consistent, repeatable setups for a systematic strategy.
Investor Structure
Capital held in your own brokerage account
MAM/LPOA structure — no fund commingling
Full transparency via live account access
Monthly performance reports delivered on time
Withdrawal rights retained at all times
Minimum Allocation
$7,500
Platform: BlackBull Markets
Account currency: USD
Onboarding time: 3–7 business days
Fee Structure
Performance Fee
30%
Charged on profits only. We earn when you earn.
Management Fee
5%
Annual. Applied monthly on AUM.
Entry / Exit Fee
None
No lock-up. No penalty for withdrawal.
Blue Marlin Securities
Confidential · For Qualified Investors Only
bluemarlinsecurities.com
Inquiries by appointment
Discretionary Strategy · Multi-Market
Blue Marlin Discretionary
A manager-led discretionary trading program combining macro analysis, technical precision, and institutional order flow reading across selected currency pairs and commodities. Co-operated by JorDache Darling and Sultan.
Live · Early Stage · Accepting Select Allocations
Performance Summary — May to June 2026
Total Return
+21.12%
Since inception
Avg Monthly Return
21.12%
First full month (May)
Account Balance
$121K
Live verified
Weekly Return
4.91%
Avg weekly since live
Max Drawdown
16.02%
Recovered — see note
Recovery Factor
1.63
Profit vs max drawdown
The 16.02% drawdown occurred in late May during a period of heightened volatility. The account recovered fully and closed May at approximately +19.77%, then continued to advance into June. The recovery demonstrates active risk management and the manager's ability to adapt positioning under pressure — a defining quality of discretionary capital management.
⬡  Early live stage — 26 days of verified performance. Investors entering now participate in the strategy's foundational growth phase. Full trade history available upon request.
Strategy Profile
Discretionary execution — human judgment applied
Macro-informed directional bias
Institutional order flow and SMC methodology
Multi-market — currencies and commodities
Active position management per session
Co-managed by two senior practitioners
Why Discretionary
Algorithmic systems excel in defined market conditions. Discretionary managers add a layer of judgment that adapts to events, sentiment shifts, and structural changes that algorithms cannot immediately process. Blue Marlin discretionary is designed to complement, not compete with, systematic approaches.
Investor Structure
Capital held in your own brokerage account
MAM/LPOA structure — no fund commingling
Full transparency via live account access
Monthly performance reports delivered on time
Withdrawal rights retained at all times
Minimum Allocation
$7,500
Platform: BlackBull Markets
Account currency: USD
Onboarding time: 3–7 business days
Fee Structure
Performance Fee
50%
Charged on profits only. No performance — no fee.
Management Fee
None
Pure performance alignment. We grow together.
Entry / Exit Fee
None
No lock-up. No penalty for withdrawal.
Blue Marlin Securities
Confidential · For Qualified Investors Only
bluemarlinsecurities.com
Inquiries by appointment
Algorithmic Strategy · Forex Majors
Oracle
A systematic mean-reversion algorithm trading major forex pairs. Designed for low-volatility capital growth with tight risk parameters — targeting consistent positive expectancy across diverse market conditions.
Early Live Phase · Expressions of Interest Now Open
Early Performance — First 27 Days Live
Total Return
+34.13%
27 days since inception
Max Drawdown
6.89%
Lowest of all three strategies
Recovery Factor
3.59
Strong capital recovery metric
Sharpe Ratio
0.42
Risk-adjusted return quality
May Return
~32%
First full month
Volatility Ratio
0.22
Low relative to return profile
Oracle carries the most conservative risk profile in the Blue Marlin portfolio — a 6.89% maximum drawdown against a 34% return in its opening month represents an exceptional early risk-return ratio. The strategy is currently in its validation phase. Allocations will open formally once a 90-day live track record has been established.
◈
Formally Opening Q3 2026
Oracle is currently in its live validation phase. Blue Marlin does not rush capital allocation decisions — a strategy earns investor capital through a proven track record, not early performance alone. Qualified investors who register their interest now will receive priority access, full documentation, and early reporting visibility ahead of the formal Q3 opening.
Register Interest
Strategy Profile
Trades major forex pairs (EURUSD, GBPUSD, USDJPY, USDCHF)
Mean-reversion methodology (ORACLE REVERSION v1.0)
Algorithmic execution — no discretionary interference
Tight risk parameters per trade
Designed for portfolio diversification alongside Heist V7
Portfolio Positioning
Oracle's low 6.89% drawdown profile and forex focus make it a natural diversifier alongside Heist V7's Gold exposure. Investors in both strategies benefit from non-correlated return streams — reducing portfolio volatility while maintaining growth potential.
Anticipated Structure
Minimum allocation: $7,500
Platform: BlackBull Markets via MAM/LPOA
Performance fee: 30% on profits
Management fee: 5% annual
No lock-up. Full transparency.
Timeline
Expressions of interest accepted now. Priority documentation and early reporting access provided to registered investors. Formal allocation opening:
Q3 2026
upon completion of 90-day validation period.
Blue Marlin Securities
Confidential · For Qualified Investors Only
bluemarlinsecurities.com
Inquiries by appointment
IMPORTANT NOTICE — This document is confidential and intended solely for the recipient. It does not constitute financial advice, a solicitation, or an offer to invest. Past performance is not indicative of future results. Trading involves significant risk of loss and may not be suitable for all investors. All performance data is drawn from live, verified trading accounts and is accurate as of the date of preparation. Investors should conduct their own due diligence and seek independent professional advice before making any capital allocation decision. Blue Marlin Securities operates a MAM/LPOA structure; investor capital is held in individually named brokerage accounts at all times.