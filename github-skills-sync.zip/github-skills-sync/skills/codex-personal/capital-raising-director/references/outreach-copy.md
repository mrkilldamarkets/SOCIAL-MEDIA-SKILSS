Blue Marlin Securities — Outreach Copy Suite
Capital Raising · Outreach Suite
Blue Marlin Securities
Investor Outreach Copy — Four Channels · Three Strategies
◈
Channel 01 — Your Audience
Content followers · Warm trust · Already watching you operate
Warmest
TRUST LEVEL
High — they follow your operator journey
PSYCHOLOGY
They want in on what you're building
TONE
Insider access. Not a pitch. A door opening.
FORMAT
Instagram caption + Story DM trigger
Instagram Caption — Managed Capital Announcement
Caption
I've been managing capital for a while now.

For the most part, I kept it quiet. Built the systems, refined the process, stacked the track record.

Now it's time to open the door.

Blue Marlin Securities is accepting investor allocations across three strategies:
Heist V7
— algorithmic Gold trading. Live since August 2025. +58.98% verified. $1.97M profit generated on a $7M account.
Blue Marlin Discretionary
— active management across forex and commodities. +21% in the first 26 days live.
Oracle
— low-drawdown algorithmic forex. 6.89% max drawdown. Taking expressions of interest for Q3.

Your capital stays in your own brokerage account. Full transparency. Monthly reports. MAM/LPOA structure — no pooled funds.

Minimum: $7,500.

If this is relevant to you, drop a comment or DM me directly. I'll send through the full strategy documentation.

Not a pitch. Not hype. Just a door opening for people who've been watching and want to know more.
PSYCHOLOGY NOTE —
Opens with restraint ("kept it quiet"), not urgency. Builds authority before numbers. Numbers are specific and verifiable — not marketing. Closes with "not a pitch" which is itself the most effective pitch frame with a warm audience.
Instagram Story — Poll / Tap to DM Trigger
Story
Option A — Poll Story
Text overlay:
"Been running managed capital accounts since August.
+58% on the flagship strategy. $1.97M generated.
Now opening allocations.

Minimum $7,500. Your capital. Your account. Full transparency.

Curious?"

[ YES, TELL ME MORE ]  |  [ NOT FOR ME ]

—
Option B — Question Box Story
Text overlay:
"If I told you I've been running a verified $7M trading account since August at +59% — would you want to know how to get your capital in?

Drop your question below."

—
Reply Template (when they respond YES or ask a question):
"Good — here's the short version.

Blue Marlin Securities runs three strategies. The flagship (Heist V7) has been live since August 2025. $7.17M account. $1.97M profit verified on Myfxbook. 4.95% average monthly return.

Your capital stays in your own account. I can only execute trades — I never hold your money. You can withdraw at any time.

Minimum allocation is $7,500. I'll send you the one-pager now — takes 2 minutes to read. If it makes sense we can get on a quick call."
NOTE —
Poll story pre-qualifies interest passively. The DM reply template moves fast — data first, structure second, call last. No chasing, no follow-up pressure built in.
◈
Channel 02 — Personal Network
Friends · Family · Former colleagues · Existing contacts
High Trust
TRUST LEVEL
Personal — they know you
PSYCHOLOGY
Risk is social, not financial. Fear of losing money with someone they know.
TONE
Direct. Personal. Honest about the risk. Not salesy.
FORMAT
WhatsApp/iMessage DM · Voice note follow-up option
WhatsApp / iMessage — Initial Outreach
DM
Hey [Name], hope you're good.

I wanted to reach out to you specifically because I know you're someone who actually thinks about where your money is working.

I've been running managed trading accounts under Blue Marlin Securities for the past several months — been keeping it relatively private while I built the track record. The flagship strategy (Heist V7) has been live since August 2025 and has generated over $1.97M profit on a $7M account. Verified on Myfxbook, so it's all publicly checkable.

I'm now opening allocations to a small number of people I trust.

Here's how it works — your capital stays in your own brokerage account the entire time. I have limited trading access only via a MAM structure. You can withdraw whenever. Monthly performance reports. Full transparency.

Minimum to start is $7,500.

I'm not going to oversell this — trading involves risk and the account has had drawdowns. But the track record is real and the structure is clean.

Worth a 15-minute call to see if it makes sense for you?
PSYCHOLOGY NOTE —
"I wanted to reach out to you specifically" — personalization removes the mass-outreach feel. Proactively acknowledges risk before they can object — removes the fear of being misled. The MAM structure explanation is the key trust element for personal network contacts who worry about handing money over.
Follow-Up — No Response After 5-7 Days
DM
Hey — no pressure at all if the timing isn't right or it's not your thing.

If you want I can just send the one-pager so you have it. No obligation to do anything with it.

If not, all good — just wanted to make sure you at least had visibility on it.
NOTE —
Single soft follow-up only. "No pressure" and "all good" reduce social friction. Offering the document keeps the door open without asking for a commitment. Never send a second follow-up after this.
◈
Channel 03 — Cold Outreach
HNWIs · Entrepreneurs · Business owners · LinkedIn · Email
Cold
TRUST LEVEL
Zero — start from credibility
PSYCHOLOGY
Skepticism is the default. Earn attention before asking for anything.
TONE
Institutional. Evidence-first. Respectful of their time.
FORMAT
Cold email (primary) · LinkedIn DM (secondary)
Cold Email — Version A (Heist V7 Lead Strategy)
Email
Subject: Managed capital allocation — Blue Marlin Securities
[First Name],

My name is JorDache Darling. I operate Blue Marlin Securities, a capital allocation platform running verified managed trading strategies across Gold and major forex pairs.

I'm reaching out to a small number of qualified individuals about our current allocation openings.

The flagship strategy, Heist V7, has been live since August 2025 on a live USD account at Tag Markets. Current verified performance:

— Total gain: +58.98%
— Average monthly return: 4.95%
— Net profit generated: $1.97M
— Account balance: $7.17M
— Track record: Verified on Myfxbook (publicly checkable)

Structure: Your capital is held in your own brokerage account via a MAM/LPOA arrangement. I have limited power of attorney to execute trades only — you retain full ownership, visibility, and withdrawal rights at all times.

Minimum allocation: $7,500. Fee structure: 30% performance, 5% management annually. No entry or exit fees.

If this is relevant to your current capital allocation, I'm happy to share the full strategy documentation and answer any questions directly. A 15-minute call is usually enough to determine if there's a fit.

No obligation either way.

JorDache Darling
Blue Marlin Securities
bluemarlinsecurities.com
PSYCHOLOGY NOTE —
Opens with identity and credibility immediately — no small talk. The bullet-point performance data is scannable and specific — skeptics check numbers fast. The MAM/LPOA explanation is front-and-center because cold contacts fear losing control of capital more than anything else. "No obligation" at the end reduces the perceived cost of responding.
LinkedIn DM — Short Version (Connection Request + Follow)
DM
Connection Note (300 char limit):
"Hi [Name] — I run Blue Marlin Securities, a managed capital platform. We have a verified 9-month live track record (+58.98% on a $7M account). Thought this might be relevant to your work. Happy to share more if useful."

—
Follow-up DM after connection accepted (24–48 hours later):
"Thanks for connecting, [Name].

Quick context — Blue Marlin Securities operates managed trading strategies across Gold and forex. Our flagship account (Heist V7) has been live since August 2025 with $1.97M in verified profit on a $7.17M account.

Investor capital is held in individually named brokerage accounts — no pooled funds, full transparency, withdrawal available at any time. Minimum: $7,500.

If it's relevant to you now or in future, I'm happy to send through the one-pager. No call needed at this stage — just documentation.

Let me know."
NOTE —
LinkedIn connection note is purely credibility — no ask. The follow-up DM leads with proof, explains the structure (which is the primary trust barrier for cold contacts), and offers the document instead of a call. Lower friction = higher response rate at cold stage.
Cold Email Follow-Up Sequence (If No Response)
Email
Follow-Up 1 — Day 5:
Subject: Re: Managed capital allocation — Blue Marlin Securities

[First Name], following up briefly on the below.

If the timing isn't right, no issue at all — I'll leave it here. If there's any interest in reviewing the documentation, happy to share.

JorDache

—
Follow-Up 2 (Final) — Day 12:
Subject: Re: Managed capital allocation — Blue Marlin Securities

[First Name] — last note on this.

If this isn't the right fit right now, completely understood. I'll close out the thread here.

If anything changes or you'd like to revisit at a later stage, you can find us at bluemarlinsecurities.com.

JorDache Darling
Blue Marlin Securities
NOTE —
Two follow-ups maximum on cold outreach. No urgency. No pressure. The "last note" close is a proven response trigger — people often reply when they feel the door is closing without any social cost to saying no. After two follow-ups: move on.
◈
Channel 04 — Referral Partners
Introducers · Content creators · Finance networks · Complementary businesses
Partners
TRUST LEVEL
Variable — relationship dependent
PSYCHOLOGY
They need to trust you before trusting you with their audience/clients
TONE
Peer-to-peer. Mutual value. Not recruitment.
FORMAT
Email or DM depending on relationship
Referral Partner — Initial Outreach (Known Contact)
Email / DM
Hey [Name],

Hope things are good on your end.

I'm reaching out because I'm building out the partner side of Blue Marlin Securities — the capital management operation I run alongside my trading brand.

The flagship strategy (Heist V7) has been live since August 2025 — $7.17M account, $1.97M profit verified, 4.95% average monthly return. Two additional strategies now live. All verified track records.

I'm working with a small number of partners who have audiences or client networks that could benefit from an introduction to managed capital allocation. The arrangement is straightforward — you introduce, I handle everything operationally, and I compensate you for any allocations that result.

This isn't asking you to sell anything to your audience. It's giving people in your network access to something they can evaluate themselves. The documentation handles the education.

If this seems like something worth a conversation, I'd keep it to 20 minutes — I'll walk you through the strategies and structure and we can see if the fit makes sense. No pressure if it doesn't align with what you're building.

JorDache
PSYCHOLOGY NOTE —
Peer framing ("hope things are good") before any business. Leads with the proof point so they can self-assess credibility before the conversation. "I'm not asking you to sell anything" directly removes the biggest objection partners have. Compensation is mentioned but not specified — that happens on the call, not in the initial message.
Referral Partner — Brief (Sent After Initial Conversation)
Brief Doc
BLUE MARLIN SECURITIES — PARTNER BRIEF
Confidential — For Partner Use Only
—
What we do
Blue Marlin Securities manages investor capital across three verified trading strategies. Investor capital is held in individually named brokerage accounts — we never hold client money. Monthly reports. Full transparency.
The strategies
Heist V7 (Lead Strategy)
Algorithmic Gold trading. Live since August 2025.
+58.98% gain · $1.97M net profit · $7.17M account verified
Max drawdown: 26.21% (recovered) · Avg monthly: 4.95%

Blue Marlin Discretionary
Manager-led multi-market trading. Live May 2026.
+21.12% in first month · Max drawdown: 16.02% (recovered)

Oracle (Pipeline — Q3 2026)
Algorithmic forex. 27 days live.
+34.13% · 6.89% max drawdown · Low-volatility profile
Minimum allocation
$7,500 per strategy. Multiple strategies available.
Fee structure
Heist V7 + Oracle: 30% performance / 5% management
Blue Marlin Discretionary: 50% performance / no management fee
Partner arrangement
Referral compensation is agreed individually and documented before any introduction is made. Standard arrangement: revenue share on performance fees generated from referred AUM, paid monthly.
What you provide
An introduction. We handle documentation, onboarding, reporting, and everything operational.
What your audience/clients receive
Full strategy documentation. Discovery call with JorDache directly. No pressure. Full right to review and decline.
Track record verification
All performance data is publicly verifiable at myfxbook.com. Links available on request.
Next step
If you'd like to move forward, I'll prepare a referral link or tracking code specific to your introductions and we can agree the compensation terms formally before anything goes live.

bluemarlinsecurities.com
NOTE —
This brief is sent after the initial conversation, not before. Partners need context before they'll share their network. This doc answers every question they'll be asked by their audience/clients before those questions get raised. Formal compensation discussion happens after the brief — never before trust is established.
◈
Live Objection Responses
DM · Call · In-person — use as needed
"The fees seem high — 50% performance?"
The fee is performance-only. If the account doesn't grow, neither do I. A 50% share of consistent monthly growth is very different to a 50% fee on a flat or losing account — and that's the structure here. You only pay when there's something to pay on.
"What if I lose money? What happens to my capital?"
Your capital never leaves your account. The MAM/LPOA structure means I have limited trading access only — I cannot deposit, withdraw, or transfer your funds. If you want out, you withdraw directly from your broker account. Full ownership stays with you throughout.
"The drawdown on Heist V7 is 26% — that's a lot."
It is — I won't minimise that. The account had a significant volatility event in October. What I'd point to is what came after: the strategy recovered and went on to produce its strongest period of returns. The full trade history is available — I'd rather you evaluate it with everything visible than take my word for it.
"Blue Marlin and Oracle have barely any history."
That's accurate — both are in early live phase. Heist V7 has the 9-month verified track record. The other two are options for investors who want exposure to those strategies at this stage, understanding what that means. Oracle in particular is accepting expressions of interest now with formal allocation in Q3 when there's more history to evaluate.
"How do I know this isn't a scam?"
The track record is on Myfxbook — publicly searchable, not a screenshot I made. The account is live, real-money, and has been trading continuously since August 2025. The MAM structure means I physically cannot access your funds outside of executing trades. You can verify the broker, the account, and the history independently before allocating a single dollar.
"$7,500 is too much to start."
The minimum is set based on what the MAM structure can properly manage — below a certain threshold the fee economics don't work for either side. If the timing isn't right I'd rather you wait until it is than allocate capital you're not comfortable committing. There's no urgency on our end.
Blue Marlin Securities
Outreach Copy Suite — Confidential Internal Document
Prepared June 2026
bluemarlinsecurities.com